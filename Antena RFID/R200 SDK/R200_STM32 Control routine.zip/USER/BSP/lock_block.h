#ifndef __LOCK_BLOCK_H__
#define __LOCK_BLOCK_H__




extern void lock_block(void);


#endif /* LOCK_BLOCK*/
