#ifndef __BSP_GPIO_H__
#define __BSP_GPIO_H__

#include "stm32f1xx_hal.h"
#include "main.h"

extern void GPIO_Init(void);
uint16_t modbusAddRaed(void);

#endif  
